# Testrail Cassandra image

To be extended...

## How to build the image?

```
docker build -t testrail/cassandra:latest .
```
