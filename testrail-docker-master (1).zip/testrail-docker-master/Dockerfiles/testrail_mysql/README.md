# Testrail mysql image

To be extendeded...

## How to build the image?

Just build it ;-)

```
docker build -t testrail/mariadb:latest .
```

## How to run the image

When starting the container, it accepts a URL, which points to a DB-dump, as the last argument.